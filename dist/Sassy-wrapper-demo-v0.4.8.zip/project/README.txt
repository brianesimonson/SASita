Place required CSV/native table inputs here, or use --project to point the runner at your existing project folder. External files are not copied by this demo.
